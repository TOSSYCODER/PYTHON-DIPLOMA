import cv2

for i in range(1,10):
    a = ('C:\\Users\\TOUSIF\\Desktop\\PYTHON WORKSHOP\\image processing\\task\\' + 'a (' + str(i) + ')' + '.jpg')
    # print(a)
    img = cv2.imread(a,0)
    # print(img)
    resized_height = img.shape[0]//2
    resized_width = img.shape[1]//2
    resized_img = cv2.resize(img,(resized_width,resized_height))
    s = ('C:\\Users\\TOUSIF\\Desktop\\PYTHON WORKSHOP\\image processing\\task\\' + 'new_' + 'a (' + str(i) + ')' + '.jpg')
    cv2.imwrite(s, resized_img)