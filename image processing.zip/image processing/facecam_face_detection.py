import cv2

c = 0
fc = (r"C:\Users\TOUSIF\Desktop\PYTHON WORKSHOP\image processing\haarcascade_frontalface_default.xml")
v = (0)
face_cascade = cv2.CascadeClassifier(fc)
vid = cv2.VideoCapture(v)

# print(type(vid))
# print(vid)
check, frame = vid.read()
while (check == True):
    # c+=1
    check, frame = vid.read()
    # print(check)
    # print(frame)
    # cv2.imshow("VIDEO KE FRAMES!!", frame)
    # cv2.waitKey(1)
    # c=c+1
    # img = cv2.imread(frame.(),1)
    grey_img = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    faces = face_cascade.detectMultiScale(grey_img, scaleFactor = 1.3, minNeighbors= 8)
    for x, y, w, h in faces:
        img = cv2.rectangle(frame, (x,y), (x+w, y+w), (0,0,255), 3)
    cv2.imshow("FACE-DETECTION",frame)
    key = cv2.waitKey(10)
    c=c+1
    if (key == ord('q')):
        break

print("NO. OF FRAMES ARE:", c)
cv2.destroyAllWindows()

vid.release()

