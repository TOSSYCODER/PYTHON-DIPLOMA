import cv2

face_cascade = cv2.CascadeClassifier(r"C:\Users\TOUSIF\Desktop\PYTHON WORKSHOP\image processing\haarcascade_frontalface_default.xml")

img = cv2.imread(r"C:\Users\TOUSIF\Desktop\PYTHON WORKSHOP\image processing\face.jpg",1)
# resized_height = img.shape[0]//3
# resized_width = img.shape[1]//3
# resized_img = cv2.resize(img,(resized_width,resized_height))

# grey_img = cv2.cvtColor(resized_img, cv2.COLOR_RGB2GRAY)
grey_img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

# print(grey_img)

faces = face_cascade.detectMultiScale(grey_img, scaleFactor = 1.05, minNeighbors= 5)

print(type(faces))
print(faces)

for x, y, w, h in faces:
    img = cv2.rectangle(img, (x,y), (x+w, y+w), (0,255,0), 3)

cv2.imshow("FACE-DETECTION",img)
key = cv2.waitKey(0)
if (key == ord('q')):
        break
cv2.destroyAllWindows()