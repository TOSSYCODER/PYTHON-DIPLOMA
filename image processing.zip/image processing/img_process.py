import cv2

img = cv2.imread("cool_chacha.jpg",0)

# print(type(img))
print(img)
# print(img.shape)
height = img.shape[0]
width = img.shape[1]
# print(height, width)
resized_height = height//3
resized_width = width//3

# print(resized_height,resized_width)

resized_img = cv2.resize(img,(resized_width,resized_height))

cv2.imwrite("smarty_chacha.jpg", resized_img)

cv2.imshow("COOL_CHACHA",resized_img)
cv2.waitKey(0)
cv2.destroyAllWindows()