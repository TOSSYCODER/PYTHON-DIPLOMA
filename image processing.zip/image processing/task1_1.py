import cv2
import glob

all_img = glob.glob(r"C:\Users\TOUSIF\Desktop\PYTHON WORKSHOP\image processing\task1_1\*.jpg")
# print(all_img)

for a in all_img:
    img = cv2.imread(a,0)
    # print(img)
    resized_height = img.shape[0]//2
    resized_width = img.shape[1]//2
    resized_img = cv2.resize(img,(resized_width,resized_height))
    s = ""
    cv2.imwrite(s, resized_img)